package org.tiling.misspelling.phonetic;

public interface PhoneticEncoder {
	public String calculateCode(String string);
}
